# Manga Host Downloader
A downloader of manga  of manga host site

How use (in portuguese): https://www.youtube.com/watch?v=uU2kczXOWG4

It is necessary that ruby be installed

Due of an update in the site, this program currently does work